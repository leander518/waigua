# Wurst Hack端汉化版

这是一个基本完成汉化的wurst hack端，基于wurst最新版本制作。
- 当wurst更新的时候，这个仓库可能不会更新

## 下载和安装

- 你可以在[这里](https://wwfb.lanzoue.com/b032gu5re)下载最新的wurst cn端汉化版,密码:6398
## 图片（汉化效果）
- ![Snipaste_2023-06-02_23-26-48](https://github.com/dingzhen-vape/wurst_cn/assets/75886707/4e6f4350-aaf6-410b-88eb-23a221df6090)
- ![Snipaste_2023-06-02_23-26-36](https://github.com/dingzhen-vape/wurst_cn/assets/75886707/08332701-bd9e-40ab-8b60-4623c0835325)
## 版权
- 一切版权归属Alexander01998
## 特别感谢
- Bing chat
## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=dingzhen-vape/WurstCN&type=Timeline)](https://star-history.com/#dingzhen-vape/WurstCN&Timeline)
